import express from 'express';
import Users from './users';
import ListTasks from './listTasks';
import createTask from './createTask';

let router = express.Router();

router.get('/test', (req, res) => {
	res.send('test data for server ** ');
});

router.get('/listTasks', ListTasks);
router.post('/create', createTask);
router.post('/users', Users);

export default router;
