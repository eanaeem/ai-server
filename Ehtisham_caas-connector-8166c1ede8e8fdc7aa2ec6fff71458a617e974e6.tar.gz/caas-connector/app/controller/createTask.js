import axios from 'axios';
import Config from '../config';

const createTask = (req, res) => {
    const { taskName, connector, bucket_name } = req.body;
    const querySring = `?connector=${connector}&task_name=${taskName}`;
    const url = `${Config.baseUrl}${Config.createTask}${querySring}`;

    console.log('create task \n', req.body, url);
    axios.post(url, { bucket_name })
        .then((response) => {
            res.send('task saved');
        })
        .catch(error => {
            console.log('\n\nlist task error');
            // res.send(error)
        });
}
export default createTask;
