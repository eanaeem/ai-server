import axios from 'axios';
import ListTask from '../models/listTaskModel';
import Config from '../config';

const ListTasks = (req, res) => {
    const url =`${Config.baseUrl}${Config.listTasks}`;
    console.log('\n listtasks', url);
    axios.get(url)
        .then((response) => {
            response.data.forEach(item => {
                const task = new ListTask(item);
                task.save((err, item, rows) => {
                    // if (err) console.log('\n\n List Task not saved successfully!*****\n', err);
                    // console.log('\n\n Item!*****\n', item);
                    // console.log('\n\n Item!*****\n', rows);
                });
            });

            res.send('ok');
        })
        .catch(error => {
            console.log('\n\nlist task error', error.code);
            res.send(error.code)
        });
        
}
export default ListTasks;
