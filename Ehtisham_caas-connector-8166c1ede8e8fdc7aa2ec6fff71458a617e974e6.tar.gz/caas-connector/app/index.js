import express from 'express';
import mongoose from 'mongoose';
import logger from 'morgan';
import bodyParser from 'body-parser';
import cors from 'cors';
import morgan from 'morgan';


import routes from './controller';
import Config from './config/index';

const app = express();
app.use(morgan('combined'));
app.use(logger());
// app.use(cors({
// 	origin: "http://localhost:3000",
// }));


let { db, port, remoteDb } = Config;
port = process.env.PORT || port;


mongoose.connect(remoteDb,  (err) => {
	if (err) console.log('*** Error connecting to db****');
	else console.log('****connected to db****');
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/api', routes);

app.listen(port, () => console.log(`Example app listening on port ${port}`));