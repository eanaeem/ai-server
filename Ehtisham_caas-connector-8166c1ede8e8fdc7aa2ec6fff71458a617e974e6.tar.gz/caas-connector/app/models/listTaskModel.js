import mongoose from 'mongoose';
let Schema = mongoose.Schema;

let listTaskSchema = new Schema({
    connector: String,
    task_name: { type: String, required: true, unique: true },
    created_at: Date,
  });
  
let ListTask = mongoose.model('ListTask', listTaskSchema);

export default ListTask;