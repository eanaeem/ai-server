const Config = {
	db: 'mongodb://localhost/cas',
	remoteDb: 'mongodb://sham:shami007@aws-eu-west-1-portal.10.dblayer.com:18496/cas?ssl=true',
	port: 3000,
	baseUrl: 'https://api.nonprod.aws.dentsufusion.com',
	listTasks :  '/connector_tasks/list-tasks',
	createTask: '/connector_tasks/create-task'
};

export default Config;
